sudo rmmod nv_imx390 
sudo rmmod max9296 
